//
// Created by morganizm on 4/21/23.
//

#ifndef EX2_THREAD_H
#define EX2_THREAD_H
#ifndef THREAD_H
#define THREAD_H

#include <setjmp.h>
#include <stdio.h>
#include <setjmp.h>
#include <signal.h>

// Constants
#define STACK_SIZE 4096
#define JB_SP 6
#define JB_PC 7

// Enum
enum ThreadStatus {RUNNING, READY, SLEEPING};

class Thread {
public:
    sigjmp_buf env;
// Constructor
    Thread(int threadId, ThreadStatus threadStatus) : threadId(threadId),
                                                      threadStatus(threadStatus), leftToSleep(0),  quantumsRunning(0)
    {}
    Thread() : threadId(-1), threadStatus(READY), leftToSleep(0), quantumsRunning(0)
    {}


// Member functions
    void decreaseLeftToSleep();
    void increaseQuantumRunning();
    void setNewStatus(ThreadStatus newthreadStatus);
    int returnLeftToSleep() const;
    void setLeftToSleep(int newLeftToSleep);
    int returnThreadId() const;
    int returnQuantumNum() const;
    void setEntryPoint(void (*entry_point)(void));
    void setEnvPc();
    int saveMask();

private:
// Member variables
    int threadId;
    char stack[STACK_SIZE];
    int threadStatus;
    int leftToSleep;
    int quantumsRunning;
    void (*entryPoint)(void){};
};

#endif // THREAD_H
#endif //EX2_THREAD_H
