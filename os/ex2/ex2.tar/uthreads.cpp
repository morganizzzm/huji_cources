// Created by Elon on 07/04/2023.
#include <iostream>
#include "uthreads.h"
#include "Thread.h"
#include <vector>
#include <sys/time.h>
#include <algorithm>

#include <stdio.h>
#include <setjmp.h>
#include <signal.h>



#define TL_INITIATED "thread library error: the library was already initiated\n"
#define TL_FULL "thread library error: The library is full\n"
#define TL_ENTRY "thread library error: Thread's entry point is null\n"
#define TL_EXIST "thread library error: Thread with this id is not in the library\n"
#define TL_BLOCK_MT "thread library error: You can't block main thread\n"
#define TL_SLEEP_MT "thread library error: You can't put to sleep main thread\n"
#define TL_QUANTUM "thread library error: Quantum number should be positive integer\n"
#define S_MEMO "system error: Can't allocate memory\n"
#define S_SIG "system error: Problem signal mask\n"
#define S_SIGACT "system error: Sigaction error\n"
#define S_TIMER "system error: Timer error\n"


#define SECOND 1000000

int totalThreadNum;
int curThreadId;
struct itimerval timer{};
struct sigaction sa = {nullptr};
int totalQuantumNum;
int quantum;
std::vector<Thread*> readyThreads;
std::vector<Thread*> sleepingThreads;
std::vector<Thread*> blockedThreads;

Thread* allThreads[MAX_THREAD_NUM];
sigset_t currentlyBlockedSignals ;
bool isInitiated = false;

void reset_timer();

void init_currently_blocked_sigs();

void prepare_for_jump();

void decrese_sleep_counter();

void test_sleeping_counter();

void sigprocmask_with_check(int signal_num) {
    if (sigprocmask(signal_num, &currentlyBlockedSignals, nullptr) < 0){
        std::cerr << S_SIG<<std::endl;
        exit(0);
    }
}


void unblock_alarm(){
    sigprocmask_with_check(SIG_UNBLOCK);
}


void block_alarm(){
    sigprocmask_with_check(SIG_BLOCK);
}



void jump_to_thread(int tid)
{
    curThreadId = tid;
    prepare_for_jump();
    unblock_alarm();
    siglongjmp(allThreads[tid] -> env, 1);
}


void prepare_for_jump() {
    allThreads[curThreadId] ->increaseQuantumRunning();
    totalQuantumNum ++;
    allThreads[curThreadId] ->setNewStatus(RUNNING);
}


int thread_to_jump(){
//    for (auto t: readyThreads){
//        std::cout<< (*t) .threadId <<std::endl;
//    }
    Thread* firstThread = readyThreads.front();
//    std::cout << "Before:" <<firstThread->threadId<<std::endl;
    readyThreads.erase(readyThreads.begin());
//    std::cout <<"After:" << readyThreads.front()->threadId<<std::endl;
    return firstThread -> returnThreadId();

}

void jump_to_next_ready() {
    int next_thread_to_jump = thread_to_jump();
    jump_to_thread(next_thread_to_jump);
}


void yield(bool resetTimer= false)
{

    int ret_val = allThreads[curThreadId]->saveMask();
    bool did_just_save_bookmark = ret_val == 0;
//    bool did_jump_from_another_thread = ret_val != 0;
    if (did_just_save_bookmark)
    {
        if (resetTimer){
            reset_timer();
        }
        jump_to_next_ready();
    }
}



void init_all_threads() {
    for (auto & allThread : allThreads){
        allThread = nullptr;
    }
}

bool check_if_blocked(Thread* thread){
    for (auto t : blockedThreads) {
        if (thread == t) {
            return true;
        }
    }
    return false;
}

void init_currently_blocked_sigs() {
    sigaddset(&currentlyBlockedSignals, SIGVTALRM);
}

void update_sleeping_counter(){
    if (sleepingThreads.empty()){
        return ;
    }
    decrese_sleep_counter();
    for (auto it = sleepingThreads.begin(); it != sleepingThreads.end();) {


        if ((*it)->returnLeftToSleep() == 0) {
            (*it)->setNewStatus(READY);
            if (!check_if_blocked((*it))){
                readyThreads.push_back(*it);
            }
            it = sleepingThreads.erase(it);


        } else {
            ++it;
        }
    }
}

void decrese_sleep_counter() {
    auto i = sleepingThreads.begin();
    while (i!= sleepingThreads.end()){
        (*i) ->decreaseLeftToSleep();
        i++;
    }
}

void timer_handler(int sig)
{
    block_alarm();
    update_sleeping_counter();
    int ret_val = allThreads[curThreadId]->saveMask();
    bool did_just_save_bookmark = ret_val == 0;
//    std::cout<<"Bookmark value: " <<did_just_save_bookmark <<std::endl;
//    bool did_jump_from_another_thread = ret_val != 0;
    if (did_just_save_bookmark)
    {
        readyThreads.push_back(allThreads[curThreadId]);
        allThreads[curThreadId] ->setNewStatus(READY);
        reset_timer();
        jump_to_next_ready();
//
    }

    unblock_alarm();

}

int regthread_assign_id(){
    /// Find id for new thread
    if (totalThreadNum == MAX_THREAD_NUM){
        return -1;
    }
    for (int i=0;  i<MAX_THREAD_NUM; i++){
        if (allThreads[i] == nullptr){
            return i;
        }
    }
    return -1;
}

int regthread_init(thread_entry_point entry_point,  int i) {

    /// Initialize regular thread with given id i and given entry_point
    auto* regThread = new (std::nothrow) Thread(i, READY);
    if (regThread == nullptr) {
        std::cerr<< S_MEMO<<std::endl;
        return -1;
    }
    regThread->setEntryPoint(entry_point);
    totalThreadNum++;
    allThreads[i] = regThread;
    unblock_alarm();
    regThread->saveMask();
    regThread->setEnvPc();
    // update the collections since the new thread was added
    readyThreads.push_back(regThread);

    return 0;
}



void reset_timer(){
    // Install timer_handler as the signal handler for SIGVTALRM.
    sa.sa_handler = &timer_handler;
    if (sigaction(SIGVTALRM, &sa, nullptr) < 0)
    {
        std::cerr<< S_SIGACT<< std::endl;
        exit(1);
    }
    // Configure the timer to expire after 1 sec... */
    timer.it_value.tv_sec = 0;        // first time interval, seconds part
    timer.it_value.tv_usec = quantum ;        // first time interval, microseconds part

    // configure the timer to expire every 3 sec after that.
    timer.it_interval.tv_sec = 0;    // following time intervals, seconds part
    timer.it_interval.tv_usec = quantum ;    // following time intervals, microseconds part


    if (setitimer(ITIMER_VIRTUAL, &timer, nullptr))
    {
        std::cerr<< S_TIMER <<std::endl;
        exit(1);
    }

}

void free_memory(){
    for (int i=0; i<MAX_THREAD_NUM; i++) {
        if (allThreads[i] != nullptr){
            delete allThreads[i];
        }
    }
}

int check_if_thread_in_library(int tid){
    if (tid <0 || tid >= MAX_THREAD_NUM || allThreads[tid] == nullptr) {
        return -1;
    }
    return 0;
}

void removeThread(std::vector<Thread*>& threads, Thread* thread) {
    auto it = std::find(threads.begin(), threads.end(), thread);
    if (it != threads.end()) {
        threads.erase(it);
    }
}



int uthread_init (int quantum_usecs)
{
    if (quantum_usecs <= 0){
        std::cerr << TL_QUANTUM <<std::endl;
        return -1;
    }
    if (isInitiated ){
        std::cerr << TL_INITIATED <<std::endl;
        return -1;
    }

    init_currently_blocked_sigs();
    init_all_threads();
    curThreadId = 0;
    quantum = quantum_usecs;
    // Init main thread
    allThreads[0] = new (std::nothrow) Thread(0, RUNNING);
    if (allThreads[0] == nullptr){
        std::cerr<<S_MEMO<<std::endl;
        return -1;
    }
    (allThreads[0])->increaseQuantumRunning();
    isInitiated = true;
    totalThreadNum = 1;
    totalQuantumNum = 1;
    curThreadId = 0;
    reset_timer();
    return 0;
}




int uthread_spawn (thread_entry_point entry_point)
{
    //// FINE
    block_alarm();
    if (entry_point == nullptr) {
        std::cerr<< TL_ENTRY <<std::endl;
        unblock_alarm();
        return -1;
    }
    int id = regthread_assign_id();
    if (id == -1){
        std::cerr <<TL_FULL <<std::endl;
        unblock_alarm();
        return -1;
    }
    int is_initiated = regthread_init(entry_point, id);
    if (is_initiated == -1){
        std::cerr <<S_MEMO <<std::endl;
        unblock_alarm();
        return -1;
    }
    unblock_alarm();
    return id;
}


int uthread_terminate (int tid)
{
    block_alarm();
    // illegal tid
    if (check_if_thread_in_library(tid)==-1){
        std::cerr << TL_EXIST << std::endl;
        unblock_alarm();
        return -1;
    }
    // the user asks to delete the main thread
    if (tid == 0) {
        free_memory();
        exit(0);
    }
    Thread* threadToDelete = allThreads[tid];
    // delete the thread from all the relevant control structures
    removeThread(readyThreads, threadToDelete);
    removeThread(sleepingThreads, threadToDelete);
    removeThread(blockedThreads, threadToDelete);
    delete threadToDelete;
    allThreads[tid] = nullptr;
    totalThreadNum--;
    if (tid == curThreadId){
        // there is no need to set bookmark since this thread is already
        // not in the library, so we can simply jump to the next thread in ready queue
        jump_to_next_ready();
        /////// ELON: the alarm in unblocked with unblock_alarm() in jump_to_next_ready()
    }
    unblock_alarm();
    return 0;

}



int uthread_block (int tid){
    //// Fine
    block_alarm();
//    std::cout<<"I block" << tid<< std::endl;
    if  (check_if_thread_in_library(tid)==-1) {
        std::cerr<< TL_EXIST << std::endl;
        unblock_alarm();
        return -1;
    }
    if (tid == 0){
        std::cerr<< TL_BLOCK_MT << std::endl;
        unblock_alarm();
        return -1;
    }
    Thread* threadToDelete = allThreads[tid];

    if (tid == curThreadId) {
//        threadToDelete->isBlocked = true;
//        // we need to reset timer before saving threads state
//        yield(true);
        int ret_val = threadToDelete->saveMask();
        bool did_just_save_bookmark = ret_val == 0;
//    bool did_jump_from_another_thread = ret_val != 0;
        if (did_just_save_bookmark)
        {
            reset_timer();
            blockedThreads.push_back(threadToDelete);
            jump_to_next_ready();
        }
    }

    /////ELON: no need to save thread's state since it should continue running not from here
    removeThread(readyThreads, threadToDelete);
    blockedThreads.push_back(threadToDelete);
    unblock_alarm();
    return 0;

}



int uthread_resume (int tid)
{
    ////FINE
    block_alarm();
    if  (check_if_thread_in_library(tid)==-1) {
        std::cerr<<TL_EXIST<<std::endl;
        unblock_alarm();
        return -1;
    }
    if (!check_if_blocked(allThreads[tid])){
        ///already resumed
        unblock_alarm();
        return 0;
    }
    Thread* threadToAdd = allThreads[tid];
    removeThread(blockedThreads, threadToAdd);
    if (threadToAdd->returnLeftToSleep() == 0){
        removeThread(sleepingThreads, threadToAdd);
        readyThreads.push_back(threadToAdd);
    }

    unblock_alarm();
    return 0;
}



int uthread_sleep (int num_quantums)
{
    block_alarm();
    if (num_quantums <= 0){
        std::cerr << TL_QUANTUM << std::endl;
        unblock_alarm();
        return -1;
    }
    if (curThreadId == 0){
        std::cerr<< TL_SLEEP_MT << std::endl;
        unblock_alarm();
        return -1;
    }
    allThreads[curThreadId]->setLeftToSleep(num_quantums);
    allThreads[curThreadId]->setNewStatus(SLEEPING);
    sleepingThreads.push_back(allThreads[curThreadId]);
    yield(true);
    unblock_alarm();
    return 0;
}

/**
 * @brief Returns the thread ID of the calling thread.
 *
 * @return The ID of the calling thread.
*/
int uthread_get_tid ()
{
    return curThreadId;
}


/**
 * @brief Returns the total number of quantums since the library was initialized, including the current quantum.
 *
 * Right after the call to uthread_init, the value should be 1.
 * Each time a new quantum starts, regardless of the reason, this number should be increased by 1.
 *
 * @return The total number of quantums.
*/
int uthread_get_total_quantums ()
{
    return totalQuantumNum;
}

/**
 * @brief Returns the number of quantums the thread with ID tid was in RUNNING state.
 *
 * On the first time a thread runs, the function should return 1. Every additional quantum that the thread starts should
 * increase this value by 1 (so if the thread with ID tid is in RUNNING state when this function is called, include
 * also the current quantum). If no thread with ID tid exists it is considered an error.
 *
 * @return On success, return the number of quantums of the thread with ID tid. On failure, return -1.
*/
int uthread_get_quantums (int tid)
{
    if  (check_if_thread_in_library(tid)==-1) {
        std::cerr<<TL_EXIST<<std::endl;
        return -1;
    }
    return allThreads[tid]->returnQuantumNum();
}


//void thread0(void)
//{
//    int i = 0;
//    while (1)
//    {
//        ++i;
//        printf("in thread0 (%d)\n", i);
//        if (i % 3 == 0)
//        {
//
//            printf("thread0: yielding\n");
////            printf("%d\n", i);
//            yield();
//        }
//        usleep(SECOND);
//    }
//}
//
//
//void thread1(void)
//{
//    int i = 0;
//    while (1)
//    {
//        ++i;
//        printf("in thread1 (%d)\n", i);
//        if (i % 5 == 0)
//        {
//            printf("thread1: yielding\n");
//            yield();
//        }
//        usleep(SECOND);
//    }
//}
//
//void thread2(void)
//{
//    int i = 0;
//    while (1)
//    {
//        ++i;
//        printf("in thread2 (%d)\n", i);
//        if (i % 13 == 0)
//        {
//            printf("thread2: yielding\n");
//            yield();
//        }
//        usleep(SECOND);
//    }
//}
//
//
//int main()
//{
//    test_sleeping_counter();
//
//
//    return 0;
//}

void test_sleeping_counter() {
    uthread_init(1);
//    uthread_spawn(thread0);
//    uthread_spawn(thread1);
//    uthread_spawn(thread2);
////
////    readyThreads.erase(readyThreads.begin(), readyThreads.end());
////    allThreads[1]->leftToSleep = 3;
////    allThreads[1]->threadStatus = SLEEPING;
//    sleepingThreads.push_back(allThreads[1]);
////    allThreads[2]->leftToSleep = 2;
////    allThreads[2]->threadStatus = SLEEPING;
//    sleepingThreads.push_back(allThreads[2]);
////    allThreads[3]->leftToSleep = 1;
////    allThreads[3]->threadStatus = SLEEPING;
//    sleepingThreads.push_back(allThreads[3]);
//    removeThread(readyThreads, allThreads[3]);
////    int i =0 ;
////    while (i!=7) {
////        std::cout <<"i= "<<i<< std::endl;
////        std::cout <<"sleep threads:"<< std::endl;
////        for (auto t: sleepingThreads){
////            std::cout<< t->threadId<<" left to sleep:" << t->leftToSleep<<std::endl;
////        }
////        std::cout <<"ready threads:"<< std::endl;
//        for (auto t: readyThreads){
//            std::cout<< t->threadId<<" left to sleep:" << t->leftToSleep<<std::endl;
//        }
//    for (auto t: sleepingThreads){
//        std::cout<< t->threadId<<std::endl;
//    }
//        update_sleeping_counter();
//        i++;
//    }
}
